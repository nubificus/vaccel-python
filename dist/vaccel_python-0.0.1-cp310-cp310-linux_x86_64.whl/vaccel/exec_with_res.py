from vaccel.session import Session
from typing import List
from vaccel.genop import Genop, VaccelArg, VaccelOpType
from vaccel._vaccel import lib, ffi
import sys 
from ctypes import *

class Exec_Operation:
    """An Image Operation model vAccel resource
    
    Attributes:
        def_arg_write (bytes): The result of the operation
    """

    def_arg_write: bytes = bytes(100 * " ", encoding="utf-8")


    @staticmethod
    def __genop__(arg_read: List[VaccelArg], arg_write: List[VaccelArg], index: int) -> str:
        """Performs the genop operation provided in arg_read.

        Args:
            arg_read : A list of inputs
            arg_write : A list of outputs
            index : An integer

        Returns:
            The content of the `arg_write` indicated by `index`.
        """
        ses = Session(flags=0)
        Genop.genop(ses, arg_read, arg_write)
        return arg_write[index].content


class Exec_with_resource(Exec_Operation):
    """An Exec with resource model vAccel resource.

    Attributes:
        __op__: The genop operation type
    """

    __op__ = VaccelOpType.VACCEL_EXEC_WITH_RESOURCE

    @classmethod
    def exec_with_resource(self, obj: str, symbol: str, arg_read: List[VaccelArg], arg_write: List[VaccelArg]) -> str:
        """Performs the Exec using vAccel over genop.

        Args:
            object: pointer to a `shared object`-type vaccel resource
            symbol: Name of the function contained in the above shared object
            arg_read: A list of inputs

        Returns:
            arg_write: A list of outputs
        """ 
        #my_object=sys.path.append ('/usr/local/lib/libvaccel-noop.so')
        #my_object = ffi.cast("struct vaccel_shared_object *",object)
        #path = "/usr/local/lib/libvaccel-noop.so"
        #my_object = ctypes.CDLL("{}".format(path).encode())

        libc=cdll.LoadLibrary(obj)
        libc = CDLL(obj)
        print("-----------------------------------")
        print(libc)
        print("-----------------------------------")
        arg_read_local = [VaccelArg(data=int(self.__op__)),
                          VaccelArg(data=obj),VaccelArg(data=symbol)] + arg_read
        arg_write = [VaccelArg(data=bytes(100 * " ", encoding="utf-8"))]
        return self.__genop__(arg_read=arg_read_local, arg_write=arg_write, index=0)
