from vaccel.exec_with_res import Exec_with_resource
from vaccel.genop import VaccelArg

lib="/usr/local/lib/libvaccel-noop.so"

sym="mytestfunc"
myint: int = 1048576
mybytes: bytes = bytes(100 * " ", encoding="utf-8")

print("-----------------------------------")

def test_exec_with_res_genop():
    res = Exec_with_resource.exec_with_resource(lib, sym, [VaccelArg(data=myint)], [VaccelArg(data=mybytes)])
    assert res == ("")