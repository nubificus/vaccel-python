# _docs

This directory holds the Dockerfile and the bash script used to autogenerate the docs.
